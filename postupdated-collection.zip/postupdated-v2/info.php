<?php
return array(
    "name"          => __("Postupdated", "postupdated"),
    "url"           => "http://chyrplite.net/",
    "version"       => "2023.09",
	"description"   => __("Several (optional) features with post-updated date-value"),
    "author"        => array(
        "name"      => "Erwin Maas",
        "url"       => "https://exdomo.com/"
    )
);