<?php
    class Postupdated extends Modules {

		public function end_head() {			
		// fetch stylesheet
		echo "\r\n<link rel=\"stylesheet\" href=\"/test3/modules/postupdated/postupdated_styles.css\" media=\"all\">\r\n\r\n";
		}

		public function postupdated() {			
		// Do nothing, just exist being the condition called from the feathers
		}

	}